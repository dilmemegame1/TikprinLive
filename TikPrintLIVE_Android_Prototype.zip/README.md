# TikPrint LIVE — Android prototype

Prototipo inicial para Android + impresora térmica Bluetooth.

Incluye:
- selección de impresoras Bluetooth ya emparejadas;
- prueba de impresión ESC/POS;
- base preparada para conectar eventos de TikTok LIVE.

## Abrir
Importa esta carpeta en Android Studio y ejecuta la app en un teléfono Android.

## Próximo paso
Conectar la fuente real de eventos de TikTok LIVE y mapear regalo/usuario/cantidad a la plantilla de impresión.
