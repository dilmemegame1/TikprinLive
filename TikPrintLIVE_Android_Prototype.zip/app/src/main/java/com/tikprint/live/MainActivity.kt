package com.tikprint.live

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import java.util.UUID

class MainActivity : Activity() {
    private val btUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private lateinit var status: TextView
    private lateinit var printer: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }
        val title = TextView(this).apply {
            text = "TikPrint LIVE"
            textSize = 30f
            setPadding(0,0,0,24)
        }
        status = TextView(this).apply {
            text = "Estado: buscando impresoras Bluetooth…"
            textSize = 16f
        }
        printer = Spinner(this)
        val refresh = Button(this).apply { text = "Buscar impresoras" }
        val test = Button(this).apply { text = "Imprimir prueba" }
        val note = TextView(this).apply {
            text = "\nTikTok LIVE → regalo → @usuario → impresora\n\nEsta versión prepara la conexión Bluetooth y la impresión. La integración de eventos de regalos de TikTok se añadirá cuando esté disponible el acceso correspondiente."
            textSize = 15f
        }
        layout.addView(title); layout.addView(status); layout.addView(printer)
        layout.addView(refresh); layout.addView(test); layout.addView(note)
        setContentView(layout)
        refresh.setOnClickListener { scanPaired() }
        test.setOnClickListener { testPrint() }
        requestBluetoothPermission()
        scanPaired()
    }

    private fun requestBluetoothPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 100)
        }
    }

    private fun scanPaired() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { status.text = "Estado: este teléfono no tiene Bluetooth."; return }
        val names = mutableListOf<String>()
        val devices = mutableListOf<BluetoothDevice>()
        try {
            for (d in adapter.bondedDevices) {
                names.add("${d.name ?: "Sin nombre"}\n${d.address}")
                devices.add(d)
            }
        } catch (_: SecurityException) {
            status.text = "Estado: permite el acceso a Bluetooth."
            return
        }
        if (names.isEmpty()) {
            names.add("No hay impresoras emparejadas")
            status.text = "Estado: empareja primero la impresora desde Ajustes de Android."
        } else status.text = "Estado: selecciona tu impresora."
        printer.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        printer.tag = devices
    }

    private fun testPrint() {
        val devices = printer.tag as? List<*> ?: return
        val pos = printer.selectedItemPosition
        if (pos !in devices.indices) {
            Toast.makeText(this, "Selecciona una impresora", Toast.LENGTH_SHORT).show(); return
        }
        val device = devices[pos] as BluetoothDevice
        Thread {
            try {
                val socket = device.createRfcommSocketToServiceRecord(btUuid)
                socket.connect()
                val data = "\u001B@\n\u001B\u0061\u0001TIKPRINT LIVE\n\u001B\u0061\u0000\n------------------------\n@usuario\n🎁 Regalo x 1\n\nGracias por tu apoyo!\n------------------------\n\n\n\u001DVA\u0000".toByteArray(Charsets.UTF_8)
                socket.outputStream.write(data)
                socket.outputStream.flush()
                socket.close()
                runOnUiThread { Toast.makeText(this, "Impresión enviada", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "No se pudo imprimir: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }
}
